"""Reusable text-cleaning and NLP preprocessing functions."""
import re
from functools import lru_cache

import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS


def ensure_nltk_resources(download: bool = False) -> bool:
    """Check NLTK resources and optionally download them for first-time training.

    Set ``download=True`` in a trusted environment with network access. A clear
    error is raised instead of an opaque NLTK LookupError if they are unavailable.
    """
    resources = {
        "corpora/stopwords": "stopwords",
        "corpora/wordnet": "wordnet",
        "corpora/omw-1.4": "omw-1.4",
    }
    missing = []
    for resource_path, package_name in resources.items():
        try:
            nltk.data.find(resource_path)
        except LookupError:
            missing.append(package_name)
    if missing and download:
        for package_name in missing:
            nltk.download(package_name, quiet=True)
        return ensure_nltk_resources(download=False)
    if missing:
        # Training and the app remain usable in offline lab environments. The
        # fallback is still an NLP morphology step, but uses stemming instead.
        return False
    return True


@lru_cache(maxsize=1)
def _language_tools() -> tuple[set[str], WordNetLemmatizer | PorterStemmer, bool]:
    if ensure_nltk_resources():
        return set(stopwords.words("english")), WordNetLemmatizer(), True
    return set(ENGLISH_STOP_WORDS), PorterStemmer(), False


def clean_text(text: object) -> str:
    """Lowercase text, remove punctuation/special characters, and normalize spaces."""
    if text is None:
        return ""
    value = str(text).lower()
    value = re.sub(r"[^a-z\s]", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def tokenize(text: object) -> list[str]:
    """Tokenize normalized English text using a deterministic regular expression."""
    return re.findall(r"\b[a-z]+\b", clean_text(text))


def preprocess_text(text: object) -> str:
    """Clean, tokenize, remove stopwords, and lemmatize feedback for ML features."""
    if not clean_text(text):
        return ""
    english_stopwords, morphology_tool, has_wordnet = _language_tools()
    tokens = tokenize(text)
    processed_tokens = [
        morphology_tool.lemmatize(token) if has_wordnet else morphology_tool.stem(token)
        for token in tokens
        if token not in english_stopwords and len(token) > 1
    ]
    return " ".join(processed_tokens)
